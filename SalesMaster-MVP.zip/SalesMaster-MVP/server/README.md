# SalesMaster Server (Stripe + OpenAI proxy)

## Setup
1) `cd server`
2) `npm install`
3) Copy `.env.example` to `.env` and fill your keys:
   - `STRIPE_SECRET_KEY` from https://dashboard.stripe.com/apikeys
   - Create two **Prices** in Stripe: $15.99/mo (recurring) and $150 one-time (lifetime) and paste the IDs.
   - (Optional) `OPENAI_API_KEY` to get real AI answers.
4) `npm run dev`

### Endpoints
- `GET /me/subscription` → returns `{active:false}` (stub). Wire to your auth later.
- `POST /create-checkout-session` → returns `{url}` to open Stripe Checkout.
- `POST /ai-answer` { prompt } → proxies to OpenAI or returns a demo text.

## Going live
- Host this on Render/Fly/Heroku/VPS.
- In the **mobile** app, set `app.json > extra.apiUrl` to your server URL.
