import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import Stripe from 'stripe';
import OpenAI from 'openai';

const app = express();
app.use(cors());
app.use(express.json());

const stripe = process.env.STRIPE_SECRET_KEY ? new Stripe(process.env.STRIPE_SECRET_KEY) : null;
const openai = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

app.get('/', (_, res)=>res.json({ ok: true }));

app.get('/me/subscription', async (req, res) => {
  // TODO: wire real auth; for demo return inactive
  res.json({ active: false });
});

app.post('/create-checkout-session', async (req, res) => {
  if(!stripe) return res.status(500).json({ error: 'Stripe not configured' });
  const lineItems = [
    { price: process.env.STRIPE_PRICE_MONTHLY, quantity: 1 },
    // Provide lifetime as alternate option via multiple price choices:
    // Clients can switch price by showing two buttons on client; keeping simple here.
  ];
  const session = await stripe.checkout.sessions.create({
    mode: 'subscription',
    line_items: lineItems,
    success_url: process.env.SUCCESS_URL,
    cancel_url: process.env.CANCEL_URL,
  });
  res.json({ url: session.url });
});

app.post('/ai-answer', async (req, res) => {
  try{
    const prompt = (req.body?.prompt || '').toString().slice(0, 1000);
    if(openai){
      const msg = [
        { role: 'system', content: 'You are SalesMaster, a crisp sales objection handler. Give a tight, persuasive response and finish with a question that advances the sale.'},
        { role: 'user', content: prompt }
      ];
      const completion = await openai.chat.completions.create({
        model: 'gpt-4o-mini',
        messages: msg,
        max_tokens: 220,
        temperature: 0.7
      });
      const text = completion.choices?.[0]?.message?.content ?? 'No response.';
      return res.json({ text });
    } else {
      return res.json({ text: "Demo: Acknowledge their concern, restate value (ROI/speed/trust), offer a concise proof point, then ask: 'If we can show you this nets a positive return in 30 days, would you feel comfortable moving forward?'" });
    }
  }catch(e){
    res.status(500).json({ error: e.message });
  }
});

const port = process.env.PORT || 4242;
app.listen(port, ()=> console.log('Server on http://localhost:'+port));
